from flask import Flask, render_template
#from flask_ import Navigation
import jinja2
import datetime

app = Flask(__name__,template_folder='templates')
#nav = Navigation(app)

@app.route('/')
def home_fn():
    return render_template("home.html",utc_date = datetime.datetime.utcnow())

@app.route('/apps')
def apps_fn():
    return render_template("apps.html")

@app.route('/about')
def about_fn():
    return render_template("about.html")

if __name__ == '__main__':
    app.run(debug=True)